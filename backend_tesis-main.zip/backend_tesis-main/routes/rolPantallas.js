const express = require('express');
const router = express.Router();
const {
  listarRolPantallas,
  asignarRolPantalla,
  actualizarRolPantalla,
  eliminarRolPantalla
} = require('../controllers/rolPantallas.');
const autenticarToken = require('../middleware/auth');

router.get('/', autenticarToken, listarRolPantallas);
router.post('/', autenticarToken, asignarRolPantalla);
router.put('/:id', autenticarToken, actualizarRolPantalla);
router.delete('/:id', autenticarToken, eliminarRolPantalla);

module.exports = router;
