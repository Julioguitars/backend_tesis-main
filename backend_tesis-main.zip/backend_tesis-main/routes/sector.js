const express = require('express');
const router = express.Router();
const {
  listarSectores,
  crearSector,
  actualizarSector,
  eliminarSector
} = require('../controllers/sector');
const autenticarToken = require('../middleware/auth');

router.get('/', autenticarToken, listarSectores);
router.post('/', autenticarToken, crearSector);
router.put('/:id', autenticarToken, actualizarSector);
router.delete('/:id', autenticarToken, eliminarSector);

module.exports = router;
