const db = require('../config/db');

const listarClientes = (req, res) => {
  db.query('SELECT * FROM clientes', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

const crearCliente = (req, res) => {
  const {
    cedula, nombre1, nombre2, apellido1, apellido2,
    telefono, direccion, foto, tokenNotificacion
  } = req.body;

  db.query(
    'INSERT INTO clientes (cedula, nombre1, nombre2, apellido1, apellido2, telefono, direccion, foto, tokenNotificacion) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
    [cedula, nombre1, nombre2, apellido1, apellido2, telefono, direccion, foto, tokenNotificacion],
    (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ mensaje: 'Cliente creado exitosamente' });
    }
  );
};

const actualizarCliente = (req, res) => {
  const {
    nombre1, nombre2, apellido1, apellido2,
    telefono, direccion, foto, tokenNotificacion
  } = req.body;
  const { cedula } = req.params;

  db.query(
    'UPDATE clientes SET nombre1 = ?, nombre2 = ?, apellido1 = ?, apellido2 = ?, telefono = ?, direccion = ?, foto = ?, tokenNotificacion = ? WHERE cedula = ?',
    [nombre1, nombre2, apellido1, apellido2, telefono, direccion, foto, tokenNotificacion, cedula],
    (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ mensaje: 'Cliente actualizado' });
    }
  );
};

const eliminarCliente = (req, res) => {
  const { cedula } = req.params;

  db.query('DELETE FROM clientes WHERE cedula = ?', [cedula], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Cliente eliminado' });
  });
};

module.exports = {
  listarClientes,
  crearCliente,
  actualizarCliente,
  eliminarCliente
};
