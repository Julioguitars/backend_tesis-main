const db = require('../config/db');

const listarRutas = (req, res) => {
  db.query('SELECT * FROM ruta', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

const crearRuta = (req, res) => {
  const { sector_id, nombre, latitud, longitud } = req.body;
  db.query(
    'INSERT INTO ruta (sector_id, nombre, latitud, longitud) VALUES (?, ?, ?, ?)',
    [sector_id, nombre, latitud, longitud],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: result.insertId, sector_id, nombre, latitud, longitud });
    }
  );
};

const actualizarRuta = (req, res) => {
  const { sector_id, nombre, latitud, longitud } = req.body;
  const { id } = req.params;
  db.query(
    'UPDATE ruta SET sector_id = ?, nombre = ?, latitud = ?, longitud = ? WHERE id = ?',
    [sector_id, nombre, latitud, longitud, id],
    (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ mensaje: 'Ruta actualizada' });
    }
  );
};

const eliminarRuta = (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM ruta WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Ruta eliminada' });
  });
};

module.exports = {
  listarRutas,
  crearRuta,
  actualizarRuta,
  eliminarRuta
};
