const db = require('../config/db');

const listarRolLog = (req, res) => {
  db.query('SELECT * FROM rol_log_', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

const asignarRolUsuario = (req, res) => {
  const { usuario_cedula, rol_id } = req.body;
  db.query('INSERT INTO rol_log_ (usuario_cedula, rol_id) VALUES (?, ?)', [usuario_cedula, rol_id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Rol asignado', id: result.insertId });
  });
};

  const actualizarRolLog = (req, res) => {
    const { id } = req.params;
    const { fecha_fin } = req.body;

    db.query(
      'UPDATE rol_log_ SET fecha_fin = ?, activo = FALSE WHERE id = ?',
      [fecha_fin, id],
      (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ mensaje: 'Rol log actualizado y desactivado' });
      }
    );
  };

const eliminarRolLog = (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM rol_log_ WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Rol log eliminado' });
  });
};

module.exports = { listarRolLog, asignarRolUsuario, actualizarRolLog, eliminarRolLog };
