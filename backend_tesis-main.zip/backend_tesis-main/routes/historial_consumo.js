const express = require('express');
const router = express.Router();
const {
  listarHistorial,
  crearHistorial,
  actualizarHistorial,
  eliminarHistorial,
  listarHistorialPorNumeroMedidor
} = require('../controllers/historial_consumo');
const autenticarToken = require('../middleware/auth');

router.get('/', autenticarToken, listarHistorial);
router.post('/', autenticarToken, crearHistorial);
router.put('/:id', autenticarToken, actualizarHistorial);
router.delete('/:id', autenticarToken, eliminarHistorial);
router.get('/medidor/:numero_medidor', autenticarToken, listarHistorialPorNumeroMedidor);

module.exports = router;
