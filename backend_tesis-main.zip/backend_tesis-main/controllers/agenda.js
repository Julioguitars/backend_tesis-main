const db = require('../config/db');

// Listar todas las agendas
const listarAgendas = (req, res) => {
  db.query('SELECT * FROM agenda', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

// Crear una nueva agenda
const crearAgenda = (req, res) => {
  const {
    red_id,
    sector_id,
    ruta_id,
    inspector_cedula,
    medidor_id,
    causa,
    novedad,
    foto,
  } = req.body;

  console.log("📥 Datos recibidos en backend:", req.body); // 👈 Agrega esto
  
  db.query(
    'INSERT INTO agenda (red_id, sector_id, ruta_id, inspector_cedula, medidor_id, causa, novedad, foto) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    [red_id, sector_id, ruta_id, inspector_cedula, medidor_id, causa, novedad, foto],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: result.insertId, ...req.body });
    }
  );
};

// Actualizar una agenda existente
const actualizarAgenda = (req, res) => {
  const {
    red_id,
    sector_id,
    ruta_id,
    inspector_cedula,
    medidor_id,
    causa,
    novedad,
    foto,
  } = req.body;
  const { id } = req.params;

  db.query(
    'UPDATE agenda SET red_id = ?, sector_id = ?, ruta_id = ?, inspector_cedula = ?, medidor_id = ?, causa = ?, novedad = ?, foto = ? WHERE id = ?',
    [red_id, sector_id, ruta_id, inspector_cedula, medidor_id, causa, novedad, foto, id],
    (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ mensaje: 'Agenda actualizada' });
    }
  );
};

// Eliminar una agenda
const eliminarAgenda = (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM agenda WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Agenda eliminada' });
  });
};

module.exports = {
  listarAgendas,
  crearAgenda,
  actualizarAgenda,
  eliminarAgenda,
};
