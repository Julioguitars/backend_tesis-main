const express = require('express');
const router = express.Router();
const {
  listarMedidoresInteligentes,
  crearMedidorInteligente,
  actualizarMedidorInteligente,
  eliminarMedidorInteligente
} = require('../controllers/medidor_inteligente');
const autenticarToken = require('../middleware/auth');

router.get('/', autenticarToken, listarMedidoresInteligentes);
router.post('/', autenticarToken, crearMedidorInteligente);
router.put('/:id', autenticarToken, actualizarMedidorInteligente);
router.delete('/:id', autenticarToken, eliminarMedidorInteligente);

module.exports = router;
