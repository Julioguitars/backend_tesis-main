const express = require('express');
const router = express.Router();
const {
  listarRolLog,
  asignarRolUsuario,
  actualizarRolLog,
  eliminarRolLog
} = require('../controllers/rolLog');
const autenticarToken = require('../middleware/auth');

router.get('/', autenticarToken, listarRolLog);
router.post('/', autenticarToken, asignarRolUsuario);
router.put('/:id', autenticarToken, actualizarRolLog);
router.delete('/:id', autenticarToken, eliminarRolLog);

module.exports = router;