const express = require('express');
const cors = require('cors'); // 👈 importa cors
require('dotenv').config();

const app = express();

// 🛡 habilita CORS para permitir conexiones desde Flutter Web
app.use(cors());

const usuariosRoutes = require('./routes/usuarios');
const rolesRoutes = require('./routes/roles');
const pantallasRoutes = require('./routes/pantallas');
const rolLogRoutes = require('./routes/rolLog');
const rolPantallasRoutes = require('./routes/rolPantallas');
const redRoutes = require('./routes/red');
const sectorRoutes = require('./routes/sector');
const rutaRoutes = require('./routes/ruta');
const clientesRoutes = require('./routes/clientes');
const medidorNormalRoutes = require('./routes/medidor_normal');
const medidorInteligenteRoutes = require('./routes/medidor_inteligente');
const agendaRoutes = require('./routes/agenda');
const consumoRoutes = require('./routes/consumo');
const medidorRoutes = require('./routes/medidor');
const historialRoutes = require('./routes/historial_consumo');

app.use(express.json());

app.use('/api/usuarios', usuariosRoutes);
app.use('/api/roles', rolesRoutes);
app.use('/api/pantallas', pantallasRoutes);
app.use('/api/rol-log', rolLogRoutes);
app.use('/api/rol-pantallas', rolPantallasRoutes);
app.use('/api/red', redRoutes);
app.use('/api/sector', sectorRoutes);
app.use('/api/ruta', rutaRoutes);
app.use('/api/clientes', clientesRoutes);
app.use('/api/medidor-normal', medidorNormalRoutes);
app.use('/api/medidor-inteligente', medidorInteligenteRoutes);
app.use('/api/agenda', agendaRoutes);
app.use('/api/consumo', consumoRoutes);
app.use('/api/historial', historialRoutes);
app.use('/api/medidor', medidorRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
