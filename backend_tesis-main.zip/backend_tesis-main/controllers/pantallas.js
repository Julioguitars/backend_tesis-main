const db = require('../config/db');

const listarPantallas = (req, res) => {
  db.query('SELECT * FROM pantallas', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

const crearPantalla = (req, res) => {
  const { nombre, descripcion } = req.body;
  db.query('INSERT INTO pantallas (nombre, descripcion) VALUES (?, ?)', [nombre, descripcion], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ id: result.insertId, nombre, descripcion });
  });
};

const actualizarPantalla = (req, res) => {
  const { id } = req.params;
  const { nombre, descripcion } = req.body;
  db.query('UPDATE pantallas SET nombre = ?, descripcion = ? WHERE id = ?', [nombre, descripcion, id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Pantalla actualizada' });
  });
};

const eliminarPantalla = (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM pantallas WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Pantalla eliminada' });
  });
};

module.exports = { listarPantallas, crearPantalla, actualizarPantalla, eliminarPantalla };

