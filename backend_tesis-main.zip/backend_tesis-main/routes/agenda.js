const express = require('express');
const router = express.Router();
const {
  listarAgendas,
  crearAgenda,
  actualizarAgenda,
  eliminarAgenda,
} = require('../controllers/agenda');
const autenticarToken = require('../middleware/auth');

router.get('/', autenticarToken, listarAgendas);
router.post('/', autenticarToken, crearAgenda);
router.put('/:id', autenticarToken, actualizarAgenda);
router.delete('/:id', autenticarToken, eliminarAgenda);

module.exports = router;
