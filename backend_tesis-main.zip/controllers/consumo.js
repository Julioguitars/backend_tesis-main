const db = require('../config/db');

// Listar consumos
const listarConsumos = (req, res) => {
  db.query('SELECT * FROM consumo', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

// Crear consumo
const crearConsumo = (req, res) => {
  const { medidor_id, lectura, litros_consumidos, total } = req.body;
  db.query(
    'INSERT INTO consumo (medidor_id, lectura, litros_consumidos, total) VALUES (?, ?, ?, ?)',
    [medidor_id, lectura, litros_consumidos, total],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: result.insertId, ...req.body });
    }
  );
};

// Actualizar consumo
const actualizarConsumo = (req, res) => {
  const { medidor_id, lectura, litros_consumidos, total } = req.body;
  const { id } = req.params;
  db.query(
    'UPDATE consumo SET medidor_id = ?, lectura = ?, litros_consumidos = ?, total = ? WHERE id = ?',
    [medidor_id, lectura, litros_consumidos, total, id],
    (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ mensaje: 'Consumo actualizado' });
    }
  );
};

// Eliminar consumo
const eliminarConsumo = (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM consumo WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Consumo eliminado' });
  });
};
// Listar consumos por medidor_id
const listarConsumosPorMedidorId = (req, res) => {
  const { medidor_id } = req.params;
  db.query('SELECT * FROM consumo WHERE medidor_id = ?', [medidor_id], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

module.exports = {
  listarConsumos,
  crearConsumo,
  actualizarConsumo,
  eliminarConsumo,
  listarConsumosPorMedidorId, // <--- Aquí
};
