const express = require('express');
const router = express.Router();
const {
  listarClientes,
  crearCliente,
  actualizarCliente,
  eliminarCliente
} = require('../controllers/clientes');
const autenticarToken = require('../middleware/auth');

router.get('/', autenticarToken, listarClientes);
router.post('/', autenticarToken, crearCliente);
router.put('/:cedula', autenticarToken, actualizarCliente);
router.delete('/:cedula', autenticarToken, eliminarCliente);

module.exports = router;
