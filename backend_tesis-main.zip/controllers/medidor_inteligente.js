const db = require('../config/db');

const listarMedidoresInteligentes = (req, res) => {
  db.query('SELECT * FROM medidor_inteligente', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

const crearMedidorInteligente = (req, res) => {
  const { cliente_cedula, numero_medidor, latitud, longitud, fecha_instalacion } = req.body;
  db.query(
    'INSERT INTO medidor_inteligente (cliente_cedula, numero_medidor, latitud, longitud, fecha_instalacion) VALUES (?, ?, ?, ?, ?)',
    [cliente_cedula, numero_medidor, latitud, longitud, fecha_instalacion],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({
        id: result.insertId,
        cliente_cedula,
        numero_medidor,
        latitud,
        longitud,
        fecha_instalacion
      });
    }
  );
};

const actualizarMedidorInteligente = (req, res) => {
  const { id } = req.params;
  const { cliente_cedula, numero_medidor, latitud, longitud, fecha_instalacion } = req.body;
  db.query(
    'UPDATE medidor_inteligente SET cliente_cedula = ?, numero_medidor = ?, latitud = ?, longitud = ?, fecha_instalacion = ? WHERE id = ?',
    [cliente_cedula, numero_medidor, latitud, longitud, fecha_instalacion, id],
    (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ mensaje: 'Medidor inteligente actualizado' });
    }
  );
};

const eliminarMedidorInteligente = (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM medidor_inteligente WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Medidor inteligente eliminado' });
  });
};

module.exports = {
  listarMedidoresInteligentes,
  crearMedidorInteligente,
  actualizarMedidorInteligente,
  eliminarMedidorInteligente
};
