const db = require('../config/db');

const listarRedes = (req, res) => {
  db.query('SELECT * FROM red', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

const crearRed = (req, res) => {
  const { nombre, latitud, longitud } = req.body;
  db.query(
    'INSERT INTO red (nombre, latitud, longitud) VALUES (?, ?, ?)',
    [nombre, latitud, longitud],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: result.insertId, nombre, latitud, longitud });
    }
  );
};

const actualizarRed = (req, res) => {
  const { nombre, latitud, longitud } = req.body;
  const { id } = req.params;
  db.query(
    'UPDATE red SET nombre = ?, latitud = ?, longitud = ? WHERE id = ?',
    [nombre, latitud, longitud, id],
    (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ mensaje: 'Red actualizada' });
    }
  );
};

const eliminarRed = (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM red WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Red eliminada' });
  });
};

module.exports = {
  listarRedes,
  crearRed,
  actualizarRed,
  eliminarRed
};
