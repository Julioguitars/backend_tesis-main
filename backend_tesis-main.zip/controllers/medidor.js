const db = require('../config/db');

// Listar todos los medidores
const listarMedidores = (req, res) => {
  db.query('SELECT * FROM medidor', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

// Crear nuevo medidor
const crearMedidor = (req, res) => {
  const { cliente_cedula, sector_id, numero_medidor, latitud, longitud, es_inteligente } = req.body;
  db.query(
    'INSERT INTO medidor (cliente_cedula, sector_id, numero_medidor, latitud, longitud, es_inteligente) VALUES (?, ?, ?, ?, ?, ?)',
    [cliente_cedula, sector_id, numero_medidor, latitud, longitud, es_inteligente],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: result.insertId, ...req.body });
    }
  );
};

// Actualizar medidor existente
const actualizarMedidor = (req, res) => {
  const { cliente_cedula, sector_id, numero_medidor, latitud, longitud, es_inteligente } = req.body;
  const { id } = req.params;
  db.query(
    'UPDATE medidor SET cliente_cedula = ?, sector_id = ?, numero_medidor = ?, latitud = ?, longitud = ?, es_inteligente = ? WHERE id = ?',
    [cliente_cedula, sector_id, numero_medidor, latitud, longitud, es_inteligente, id],
    (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ mensaje: 'Medidor actualizado' });
    }
  );
};

// Eliminar medidor
const eliminarMedidor = (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM medidor WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Medidor eliminado' });
  });
};

module.exports = {
  listarMedidores,
  crearMedidor,
  actualizarMedidor,
  eliminarMedidor,
};
