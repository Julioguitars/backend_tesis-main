const express = require('express');
const router = express.Router();
const {
  listarRutas,
  crearRuta,
  actualizarRuta,
  eliminarRuta
} = require('../controllers/ruta');
const autenticarToken = require('../middleware/auth');

router.get('/', autenticarToken, listarRutas);
router.post('/', autenticarToken, crearRuta);
router.put('/:id', autenticarToken, actualizarRuta);
router.delete('/:id', autenticarToken, eliminarRuta);

module.exports = router;
