const express = require('express');
const router = express.Router();
const {
  listarConsumos,
  crearConsumo,
  actualizarConsumo,
  eliminarConsumo,
  listarConsumosPorMedidorId
} = require('../controllers/consumo');
const autenticarToken = require('../middleware/auth');

router.get('/', autenticarToken, listarConsumos);
router.post('/', autenticarToken, crearConsumo);
router.put('/:id', autenticarToken, actualizarConsumo);
router.delete('/:id', autenticarToken, eliminarConsumo);
router.get('/medidor/:medidor_id', autenticarToken, listarConsumosPorMedidorId);

module.exports = router;
