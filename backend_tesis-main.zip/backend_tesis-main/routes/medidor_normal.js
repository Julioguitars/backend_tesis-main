const express = require('express');
const router = express.Router();
const {
  listarMedidoresNormales,
  crearMedidorNormal,
  actualizarMedidorNormal,
  eliminarMedidorNormal
} = require('../controllers/medidor_normal');
const autenticarToken = require('../middleware/auth');

router.get('/', autenticarToken, listarMedidoresNormales);
router.post('/', autenticarToken, crearMedidorNormal);
router.put('/:id', autenticarToken, actualizarMedidorNormal);
router.delete('/:id', autenticarToken, eliminarMedidorNormal);

module.exports = router;
