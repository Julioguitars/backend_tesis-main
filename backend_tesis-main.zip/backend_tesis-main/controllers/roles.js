const db = require('../config/db');

const listarRoles = (req, res) => {
  db.query('SELECT * FROM roles', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

const crearRol = (req, res) => {
  const { descripcion } = req.body;
  db.query('INSERT INTO roles (descripcion) VALUES (?)', [descripcion], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ id: result.insertId, descripcion });
  });
};

const actualizarRol = (req, res) => {
  const { id } = req.params;
  const { descripcion } = req.body;
  db.query('UPDATE roles SET descripcion = ? WHERE id = ?', [descripcion, id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Rol actualizado' });
  });
};

const eliminarRol = (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM roles WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Rol eliminado' });
  });
};

module.exports = { listarRoles, crearRol, actualizarRol, eliminarRol };

