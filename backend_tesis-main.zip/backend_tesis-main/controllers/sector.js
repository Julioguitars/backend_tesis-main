const db = require('../config/db');

const listarSectores = (req, res) => {
  db.query('SELECT * FROM sector', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

const crearSector = (req, res) => {
  const { red_id, nombre, latitud, longitud } = req.body;
  db.query(
    'INSERT INTO sector (red_id, nombre, latitud, longitud) VALUES (?, ?, ?, ?)',
    [red_id, nombre, latitud, longitud],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: result.insertId, red_id, nombre, latitud, longitud });
    }
  );
};

const actualizarSector = (req, res) => {
  const { red_id, nombre, latitud, longitud } = req.body;
  const { id } = req.params;
  db.query(
    'UPDATE sector SET red_id = ?, nombre = ?, latitud = ?, longitud = ? WHERE id = ?',
    [red_id, nombre, latitud, longitud, id],
    (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ mensaje: 'Sector actualizado' });
    }
  );
};

const eliminarSector = (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM sector WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Sector eliminado' });
  });
};

module.exports = {
  listarSectores,
  crearSector,
  actualizarSector,
  eliminarSector
};
