const db = require('../config/db');

const listarHistorial = (req, res) => {
  db.query('SELECT * FROM historial_consumo', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

const crearHistorial = (req, res) => {
  const { medidor_id, temperatura, humedad, flujo, volumen, hora, fecha } = req.body;
  db.query(
    `INSERT INTO historial_consumo (medidor_id, temperatura, humedad, flujo, volumen, hora, fecha)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [medidor_id, temperatura, humedad, flujo, volumen, hora, fecha],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({
        id: result.insertId, medidor_id, temperatura, humedad, flujo, volumen, hora, fecha
      });
    }
  );
};

const actualizarHistorial = (req, res) => {
  const { medidor_id, temperatura, humedad, flujo, volumen, hora, fecha } = req.body;
  const { id } = req.params;
  db.query(
    `UPDATE historial_consumo
     SET medidor_id = ?, temperatura = ?, humedad = ?, flujo = ?, volumen = ?, hora = ?, fecha = ?
     WHERE id = ?`,
    [medidor_id, temperatura, humedad, flujo, volumen, hora, fecha, id],
    (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ mensaje: 'Historial actualizado' });
    }
  );
};

const eliminarHistorial = (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM historial_consumo WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Historial eliminado' });
  });
};

// Buscar historial por número de medidor
const listarHistorialPorNumeroMedidor = (req, res) => {
  const { numero_medidor } = req.params;
  const query = `
    SELECT h.*
    FROM historial_consumo h
    JOIN medidor m ON h.medidor_id = m.id
    WHERE m.numero_medidor = ?
    ORDER BY h.fecha DESC, h.hora DESC
  `;
  db.query(query, [numero_medidor], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};



module.exports = {
  listarHistorial,
  crearHistorial,
  actualizarHistorial,
  eliminarHistorial,
  listarHistorialPorNumeroMedidor, 
};
