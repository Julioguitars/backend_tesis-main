const db = require('../config/db');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
require('dotenv').config();

const listarUsuarios = (req, res) => {
  db.query('SELECT cedula, nombre1, nombre2, apellido1, apellido2, telefono, foto, sueldo, direccion, tokenNotificacion, contrasena, es_cliente FROM usuarios', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

const crearUsuario = async (req, res) => {
  const {
    cedula, nombre1, nombre2, apellido1, apellido2, telefono,
    direccion, foto, sueldo, tokenNotificacion, contrasena
  } = req.body;

  const hashedPassword = await bcrypt.hash(contrasena, 10);
  console.log('🔐 Contraseña encriptada:', hashedPassword);

  const sql = `INSERT INTO usuarios
    (cedula, nombre1, nombre2, apellido1, apellido2, telefono, direccion, foto, sueldo, tokenNotificacion, contrasena, es_cliente)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)`; // 0 = no cliente

  db.query(sql, [
    cedula, nombre1, nombre2, apellido1, apellido2, telefono,
    direccion, foto, sueldo, tokenNotificacion, hashedPassword
  ], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Usuario creado con éxito' });
  });
};


const crearCliente = async (req, res) => {
  const {
    cedula, nombre1, nombre2, apellido1, apellido2, telefono,
    direccion, foto, tokenNotificacion, contrasena
  } = req.body;

  db.query('SELECT cedula FROM usuarios WHERE cedula = ?', [cedula], async (err, results) => {
    if (err) return res.status(500).json({ error: err.message });

    if (results.length > 0) {
      return res.status(400).json({ mensaje: 'Ya existe un usuario con esa cédula' });
    }

    const hashedPassword = await bcrypt.hash(contrasena, 10);
    console.log('🔐 Contraseña cliente encriptada:', hashedPassword);

    const sql = `INSERT INTO usuarios
      (cedula, nombre1, nombre2, apellido1, apellido2, telefono, direccion, foto, tokenNotificacion, contrasena, es_cliente)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`; // 1 = cliente

    db.query(sql, [
      cedula, nombre1, nombre2, apellido1, apellido2, telefono,
      direccion, foto, tokenNotificacion, hashedPassword
    ], (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ mensaje: 'Cliente creado con éxito' });
    });
  });
};

const actualizarUsuario = (req, res) => {
  const { cedula } = req.params;
  const datos = req.body;
  const campos = Object.keys(datos).map(key => `${key} = ?`).join(', ');
  const valores = Object.values(datos);

  db.query(`UPDATE usuarios SET ${campos} WHERE cedula = ?`, [...valores, cedula], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Usuario actualizado' });
  });
};

const eliminarUsuario = (req, res) => {
  const { cedula } = req.params;
  db.query('DELETE FROM usuarios WHERE cedula = ?', [cedula], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Usuario eliminado' });
  });
};

const login = (req, res) => {
  const { cedula, contrasena } = req.body;

  db.query('SELECT * FROM usuarios WHERE cedula = ?', [cedula], async (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    if (results.length === 0) return res.status(404).json({ error: 'Usuario no encontrado' });

    const usuario = results[0];
    let coincide;

    if (usuario.contrasena.startsWith('$2b$')) {
      coincide = await bcrypt.compare(contrasena, usuario.contrasena);
    } else {
      coincide = contrasena === usuario.contrasena;
    }

    if (!coincide) return res.status(401).json({ error: 'Contraseña incorrecta' });

    if (!usuario.contrasena.startsWith('$2b$')) {
      const nuevaHash = await bcrypt.hash(contrasena, 10);
      db.query('UPDATE usuarios SET contrasena = ? WHERE cedula = ?', [nuevaHash, cedula], (err) => {
        if (err) console.error('❌ Error actualizando contraseña cifrada:', err);
        else console.log('✅ Contraseña actualizada y cifrada automáticamente');
      });
    }

    const token = jwt.sign({ cedula: usuario.cedula }, process.env.JWT_SECRET, { expiresIn: '2h' });
    res.json({ token, cedula: usuario.cedula });
  });
};

const obtenerRolYPantallas = (req, res) => {
  const { cedula } = req.params;

  const sql = `
    SELECT 
      r.id AS rol_id,
      r.descripcion AS rol,
      p.id AS pantalla_id,
      p.nombre AS pantalla,
      p.descripcion AS descripcion_pantalla
    FROM rol_log_ rl
    JOIN roles r ON rl.rol_id = r.id
    LEFT JOIN rol_pantallas rp ON r.id = rp.rol_id
    LEFT JOIN pantallas p ON rp.pantalla_id = p.id
    WHERE rl.usuario_cedula = ?
      AND (rl.fecha_fin IS NULL OR rl.fecha_fin > NOW())
      AND rp.acceso = TRUE
  `;

  db.query(sql, [cedula], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    if (results.length === 0) return res.status(404).json({ mensaje: 'El usuario no tiene un rol asignado activo o no tiene pantallas asignadas' });

    const rolInfo = {
      rol_id: results[0].rol_id,
      rol: results[0].rol,
      pantallas: results.map(r => ({
        id: r.pantalla_id,
        nombre: r.pantalla,
        descripcion: r.descripcion_pantalla
      }))
    };

    res.json(rolInfo);
  });
};

const verificarRolUsuario = (req, res) => {
  const { cedula } = req.params;

  const sql = 'SELECT sueldo, es_cliente FROM usuarios WHERE cedula = ?';

  db.query(sql, [cedula], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    if (results.length === 0) return res.status(404).json({ mensaje: 'Usuario no encontrado' });

    const usuario = results[0];

    res.json({
      esUsuarioSistema: usuario.sueldo !== null,
      esCliente: usuario.es_cliente === 1
    });
  });
};

const obtenerMedidoresPorCedula = (req, res) => {
  const { cedula } = req.params;
  const sql = `
    SELECT 
      m.id AS medidor_id,
      m.numero_medidor,
      m.latitud,
      m.longitud,
      m.es_inteligente,
      u.nombre1,
      u.apellido1,
      u.foto,
      u.direccion,
      u.es_cliente
    FROM medidor m
    JOIN usuarios u ON m.cliente_cedula = u.cedula
    WHERE m.cliente_cedula = ?
  `;
  db.query(sql, [cedula], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};


module.exports = {
  listarUsuarios,
  crearUsuario,
  crearCliente,
  actualizarUsuario,
  eliminarUsuario,
  login,
  obtenerRolYPantallas,
  verificarRolUsuario,
  obtenerMedidoresPorCedula 
};
