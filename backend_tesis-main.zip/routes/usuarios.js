const express = require('express');
const router = express.Router();
const {
  listarUsuarios,
  crearUsuario,
  crearCliente,
  actualizarUsuario,
  eliminarUsuario,
  login,
  obtenerRolYPantallas,
  verificarRolUsuario,
  obtenerMedidoresPorCedula
} = require('../controllers/usuarios');
const autenticarToken = require('../middleware/auth');

// Listar usuarios
router.get('/', autenticarToken, listarUsuarios);

// Crear usuario (no cliente)
router.post('/crear-usuario', autenticarToken, crearUsuario);

// Crear cliente (es_cliente = 1)
router.post('/crear-cliente', autenticarToken, crearCliente);

// Actualizar usuario
router.put('/:cedula', autenticarToken, actualizarUsuario);

// Eliminar usuario
router.delete('/:cedula', autenticarToken, eliminarUsuario);

// Login (no necesita token)
router.post('/login', login);

// Obtener rol y pantallas del usuario
router.get('/:cedula/rol-pantallas', autenticarToken, obtenerRolYPantallas);

//verificar rol y asoma la panatlla 
router.get('/:cedula/verificar-rol', autenticarToken, verificarRolUsuario);

router.get('/medidores/:cedula', autenticarToken, obtenerMedidoresPorCedula);

module.exports = router;
