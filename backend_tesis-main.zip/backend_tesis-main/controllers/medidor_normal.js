const db = require('../config/db');

const listarMedidoresNormales = (req, res) => {
  db.query('SELECT * FROM medidor_normal', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

const crearMedidorNormal = (req, res) => {
  const { cliente_cedula, numero_medidor, latitud, longitud, fecha_instalacion } = req.body;
  db.query(
    'INSERT INTO medidor_normal (cliente_cedula, numero_medidor, latitud, longitud, fecha_instalacion) VALUES (?, ?, ?, ?, ?)',
    [cliente_cedula, numero_medidor, latitud, longitud, fecha_instalacion],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({
        id: result.insertId,
        cliente_cedula,
        numero_medidor,
        latitud,
        longitud,
        fecha_instalacion
      });
    }
  );
};

const actualizarMedidorNormal = (req, res) => {
  const { id } = req.params;
  const { cliente_cedula, numero_medidor, latitud, longitud, fecha_instalacion } = req.body;

  // 👇 LOG PARA VER SI LLEGA EL PUT Y CON QUÉ DATOS
  console.log('🔄 ACTUALIZANDO MEDIDOR ID:', id);
  console.log('📦 DATA RECIBIDA:', req.body);

  db.query(
    'UPDATE medidor_normal SET cliente_cedula = ?, numero_medidor = ?, latitud = ?, longitud = ?, fecha_instalacion = ? WHERE id = ?',
    [cliente_cedula, numero_medidor, latitud, longitud, fecha_instalacion, id],
    (err) => {
      if (err) {
        console.error('❌ ERROR EN QUERY:', err);
        return res.status(500).json({ error: err.message });
      }
      res.json({ mensaje: 'Medidor normal actualizado' });
    }
  );
};


const eliminarMedidorNormal = (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM medidor_normal WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Medidor normal eliminado' });
  });
};

module.exports = {
  listarMedidoresNormales,
  crearMedidorNormal,
  actualizarMedidorNormal,
  eliminarMedidorNormal
};
