const express = require('express');
const router = express.Router();
const {
  listarRedes,
  crearRed,
  actualizarRed,
  eliminarRed
} = require('../controllers/red');
const autenticarToken = require('../middleware/auth');

router.get('/', autenticarToken, listarRedes);
router.post('/', autenticarToken, crearRed);
router.put('/:id', autenticarToken, actualizarRed);
router.delete('/:id', autenticarToken, eliminarRed);

module.exports = router;
