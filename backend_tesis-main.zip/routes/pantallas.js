const express = require('express');
const router = express.Router();
const {
  listarPantallas,
  crearPantalla,
  actualizarPantalla,
  eliminarPantalla
} = require('../controllers/pantallas');
const autenticarToken = require('../middleware/auth');

router.get('/', autenticarToken, listarPantallas);
router.post('/', autenticarToken, crearPantalla);
router.put('/:id', autenticarToken, actualizarPantalla);
router.delete('/:id', autenticarToken, eliminarPantalla);

module.exports = router;