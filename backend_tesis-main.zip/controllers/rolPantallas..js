const db = require('../config/db');

const listarRolPantallas = (req, res) => {
  db.query('SELECT * FROM rol_pantallas', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

const asignarRolPantalla = (req, res) => {
  const { rol_id, pantalla_id, acceso } = req.body;
  db.query('INSERT INTO rol_pantallas (rol_id, pantalla_id, acceso) VALUES (?, ?, ?)', [rol_id, pantalla_id, acceso], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Acceso asignado', id: result.insertId });
  });
};

const actualizarRolPantalla = (req, res) => {
  const { id } = req.params;
  const { rol_id, pantalla_id, acceso } = req.body;
  db.query('UPDATE rol_pantallas SET rol_id = ?, pantalla_id = ?, acceso = ? WHERE id = ?', [rol_id, pantalla_id, acceso, id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Acceso actualizado' });
  });
};

const eliminarRolPantalla = (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM rol_pantallas WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ mensaje: 'Acceso eliminado' });
  });
};

module.exports = { listarRolPantallas, asignarRolPantalla, actualizarRolPantalla, eliminarRolPantalla };