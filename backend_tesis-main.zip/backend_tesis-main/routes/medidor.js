const express = require('express');
const router = express.Router();
const {
  listarMedidores,
  crearMedidor,
  actualizarMedidor,
  eliminarMedidor,
} = require('../controllers/medidor');
const autenticarToken = require('../middleware/auth');

router.get('/', autenticarToken, listarMedidores);
router.post('/', autenticarToken, crearMedidor);
router.put('/:id', autenticarToken, actualizarMedidor);
router.delete('/:id', autenticarToken, eliminarMedidor);

module.exports = router;
