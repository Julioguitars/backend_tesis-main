const express = require('express');
const router = express.Router();
const {
  listarRoles,
  crearRol,
  actualizarRol,
  eliminarRol
} = require('../controllers/roles');
const autenticarToken = require('../middleware/auth');

router.get('/', autenticarToken, listarRoles);
router.post('/', autenticarToken, crearRol);
router.put('/:id', autenticarToken, actualizarRol);
router.delete('/:id', autenticarToken, eliminarRol);

module.exports = router;